import state.NoGumballsNoQuarter;
import state.State;

public class GumballMachine implements State.StateHolder {
    private State state = new NoGumballsNoQuarter(this, 0);

    @Override
    public void setState(State newState) {
        this.state = newState;
    }

    public void addGumballs(int count) {
        state.addGumballs(count);
    }

    public void insertQuarter() {
        state.insertQuarter();
    }
    public void removeQuarter() {
        state.removeQuarter();
    }
    public void turnHandle() {
        state.turnHandle();
    }


}
